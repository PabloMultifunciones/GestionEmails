const express = require('express');
const app = express();
const router = require('./routes');


app.use(express.urlencoded({extended: false}));
app.use(express.json());

app.use('/',router);

//Configuro una ruta public
app.use('/resources',express.static(__dirname + "/public"));

app.listen(process.env.PORT,() =>{
    console.log("El servidor se inicio: http://localhost:3000");
});