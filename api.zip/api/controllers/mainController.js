const res = require('express/lib/response');
const nodemailer = require('nodemailer');
const connection = require('../database/config');


function sendMail(email,userAdmin,password,port,host,subject,text){        

    var transporter = nodemailer.createTransport({
        host: host,
        port: port,
        secure: true,
	sendemail: true,
        auth: {
            user: userAdmin,
            pass: password
        }
    });
	
    var mailOptions = {
        from: 'Remitente',
        to: email,
        subject: subject,
        text: text
    };
    
    transporter.sendMail(mailOptions, (error, info) => {
        if(error){
	    console.log("Hubo un error al enviar el email")
        }else{
            console.log("El email fue enviado correctamente");   
        }
    });
}

exports.sendMails = (req,res) => {
    const userAdmin = req.body.user;
    const password = req.body.password;
    const port = req.body.port;
    const host = req.body.host;
    const subject = req.body.subject;
    const text = req.body.text;
    const sendTo = req.body.sendTo;  


    connection.query('SELECT * FROM users',(error,results) => {
        if(error){
            throw error;
        }else{
	    results.forEach(user => {
		if(user.role == sendTo || sendTo == 'all'){
                    sendMail(user.email,userAdmin,password,port,host,subject,text);
		}
            });
        }
    });

    res.status(200).json({success: 'ok'});
}

exports.saveUser = (req,res) => {
    const username = req.body.username;
    const role = req.body.role;
    const email = req.body.email;

    connection.query('INSERT INTO users SET ?',{username: username,role:role,email:email},(error,results) => {
        if(error){
            return res.status(400).json({
                success: false,
                message: 'Ocurrio un error al insertar los datos'
            });
        }else{
            return res.status(200).json({
                success: true,
                message: 'Insert Successfull'
            });
        }
    });
}

exports.deleteUser = (req,res) => {
    const id = req.params.id;
    console.log(id)
    connection.query(`DELETE FROM users WHERE id= '${id}'`, (error,results) => {
        if(error){
    	    throw error;
        }else{
            res.status(200).json({success: 'ok'});
        }
    });
}

exports.allUsers = (req,res) => {
    connection.query('SELECT * FROM users',(error,results) => {
        if(error){
            throw error;
        }else{
            const resultsArray = [];
            results.forEach(row => {
                resultsArray.push({id: row.id, username: row.username, email: row.email, role: row.role});
            });
            res.send(resultsArray);
        }
    });
}

exports.deleteConfiguration = (req,res) => {
    const name = req.params.name;
    connection.query(`DELETE FROM configurations WHERE name = '${name}'`, (error,results) => {
        if(error){
    	    throw error;
        }else{
            res.status(200).json({success: 'ok'});
        }
    });
}

exports.getConfigurations = (req,res) => {
    connection.query('SELECT * FROM configurations', (error,results) => {
    	if(error){
            throw error;
        }else{
            res.send(results);
        }
    });
}

exports.saveConfiguration = (req,res) => {
    const name = req.body.name;
    const user = req.body.user;
    const password = req.body.password;
    const host = req.body.host;
    const port = req.body.port;

    connection.query('INSERT INTO configurations SET ?',{name: name, user: user, password: password, host: host, port: port}, (error,results) => {
    	if(error){
            throw error;
        }else{
            console.log('Se ha guardado la configuracion');
	    res.status(200).json({success: 'ok'});
        }
    });
}