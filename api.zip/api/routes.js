const express = require('express');
const router = express.Router();
const mainController = require('./controllers/mainController');
const middlewares = require('./middlewares/middlewares');


router.post('/send-all',mainController.sendMails);

router.get('/all-users',mainController.allUsers);

router.post('/save-user',middlewares.validateUser,middlewares.ifErrors,mainController.saveUser);

router.get('/delete-user/:id',mainController.deleteUser);

router.post('/save-configuration',mainController.saveConfiguration);

router.get('/get-configurations',mainController.getConfigurations);

router.get('/delete-configuration/:name',mainController.deleteConfiguration);

module.exports = router;