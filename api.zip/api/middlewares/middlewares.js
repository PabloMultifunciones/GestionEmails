const {body,validationResult} = require('express-validator');

exports.validateUser = [
    body('username')
        .isLength({min:6})
        .withMessage('Debe tener 6 o mas caracteres'),
    body('email')
        .isEmail()
        .withMessage('Debe ser un Correo Electronico')
        .normalizeEmail(),
    body('role')
        .custom(role => {
            if(role != 'admin' && role != 'client'){
                throw new Error('Elija una de las opciones marcadas');
            }
            return true;
        })
    ];

exports.ifErrors = (req,res,next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({
            success: false,
            errors: errors.array()
        });
    }else{
        return next();
    }
}