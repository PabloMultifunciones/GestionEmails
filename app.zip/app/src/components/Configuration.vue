<template>
  <div class="card-body mb-3">
    
    <h5 class="text-center">{{configuration.name}}</h5>
    
    <div class="row">
      
      <button type="button" v-on:click="returnValues" class="btn btn-success col col-6">
        Usar
      </button>
      
      <button type="button" v-on:click="sendvalues" class="btn btn-primary col col-6" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Ver
      </button>
    </div>

  </div>
</template>

<script>
export default {
  props: {
    configuration: Object
  },
  methods: {
    sendvalues(){
      this.$emit("sendValues",this.configuration);
    },
    returnValues(){
      this.$emit("returnValues",this.configuration.name,this.configuration.user,this.configuration.port,this.configuration.host,this.configuration.password);
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.card-body{
  border-style: solid;
  border-color: white;
  border-width: 0.1rem;
  border-radius: 0.4rem;
  padding-top: 0.1rem;
}
</style>
