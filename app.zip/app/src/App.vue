<template>
  <div id="app">
    <div class="row d-flex" id="nav">
        
        <router-link to="/" id="button-nav" class="col col-12 col-lg-4 text-center p-0 m-0">
          <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 24 24" style="fill: white;transform: ;msFilter:;"><path d="M15 11h7v2h-7zm1 4h6v2h-6zm-2-8h8v2h-8zM4 19h10v-1c0-2.757-2.243-5-5-5H7c-2.757 0-5 2.243-5 5v1h2zm4-7c1.995 0 3.5-1.505 3.5-3.5S9.995 5 8 5 4.5 6.505 4.5 8.5 6.005 12 8 12z"></path></svg>
          Ver Usuarios
        </router-link>

        <router-link to="/sendmails" id="button-nav" class="col col-12 col-lg-4 text-center p-0 m-0">
          <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 24 24" style="fill: white;transform: ;msFilter:;"><path d="M20 4H6c-1.103 0-2 .897-2 2v5h2V8l6.4 4.8a1.001 1.001 0 0 0 1.2 0L20 8v9h-8v2h8c1.103 0 2-.897 2-2V6c0-1.103-.897-2-2-2zm-7 6.75L6.666 6h12.668L13 10.75z"></path><path d="M2 12h7v2H2zm2 3h6v2H4zm3 3h4v2H7z"></path></svg>        
          Enviar Correos
        </router-link>
        <router-link to="/insertuser" id="button-nav" class="col col-12 col-lg-4 text-center p-0 m-0">
          <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 24 24" style="fill: white;transform: ;msFilter:;"><path d="M4.5 8.552c0 1.995 1.505 3.5 3.5 3.5s3.5-1.505 3.5-3.5-1.505-3.5-3.5-3.5-3.5 1.505-3.5 3.5zM19 8h-2v3h-3v2h3v3h2v-3h3v-2h-3zM4 19h10v-1c0-2.757-2.243-5-5-5H7c-2.757 0-5 2.243-5 5v1h2z"></path></svg>
          Ingresar Usuario
        </router-link>
        
      
    </div>
    
    <div class="container">
      <router-view/>
    </div>
  </div>
</template>

<style scoped>

#nav{
  background-color: #342D2D;
}
#button-nav{
  color:white;
  font-size: 2rem;
  margin: 0.3rem;
  text-decoration: none;
}
#button-nav:hover{
  background-color: #535151;
}
</style>