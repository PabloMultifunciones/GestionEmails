<template>
  <div class="home">
    <div class="card mt-4">
      <div class="card-body" id="card">
      <h3 class="text-center">Datos</h3><hr>
          <form>

            <div class="row">

              <label id="about-username" for="username" class="col col-5 col-md-4 text-end">Nombre de Usuario</label>
              
              <div class="col col-6">
                <input type="text" id="username" name="username" class="form-control" v-model="username" required>
              
                <div class="alert-danger text-center mt-1" role="alert" v-show="errorUsername">
                  <strong>{{errorUsernameMessage}}</strong>
                </div>
              </div>
              
            </div>

            <div class="row mt-3">

              <label id="about-email" for="emal" class="col col-5 col-md-4 text-end">Correo Electronico</label>
              
              <div class="col col-6">
                <input type="text" id="email" name="email" class="form-control" v-model="email" required>
              
                <div class="alert-danger text-center mt-1" role="alert" v-show="errorEmail">
                  <strong>{{errorEmailMessage}}</strong>
                </div>
              
              </div>
              
            </div>

            <div class="row mt-3">

              <label id="about-role" for="role" class="col col-5 col-md-4 text-end">Rol</label>
              
              <div class="col col-6">
                
                <select class="form-select" v-model="role">
                  <option value="admin">Administrador</option>
                  <option value="client">Cliente</option>
                </select>

                <div class="alert-danger text-center mt-1" role="alert" v-show="errorRole">
                  <strong>{{errorRoleMessage}}</strong>
                </div>

              </div>
              
              
            </div>

            <div class="row mt-3 d-flex justify-content-center">
              <button type="button" id="button-send" class="col col-10 col-md-3" v-on:click="insert">Registrar usuario</button>
            </div>

          </form>
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import axios from 'axios';

export default {
  name: 'InsertUser',
  data() {
    return {
      username: "",
      email: "",
      role: "",
      errorUsername: false,
      errorEmail: false,
      errorRole: false,
      errorUsernameMessage: "",
      errorEmailMessage: "",
      errorRoleMessage: "",
      saludar:"asd"
    }
  },
  methods: {
    insert(){
      this.errorUsername = false;
      this.errorEmail = false,
      this.errorRole = false;

      axios.post('http://localhost:3000/save-user',{role: this.role, username: this.username, email: this.email})
      .then(response => {
        console.log(response);
      })
      .catch(error => {
        const errors = error.response.data.errors;
        console.log(error.response);

        errors.forEach(error => {
          if(error.param == 'username'){
            this.errorUsername = true;
            this.errorUsernameMessage = error.msg;
          }else if(error.param == 'email'){
            this.errorEmail = true;
            this.errorEmailMessage = error.msg;
          }else if(error.param == 'role'){
            this.errorRole = true;
            this.errorRoleMessage = error.msg;
          }
        });

      });
    }
  }
}
</script>

<style scoped>
#card{
  background-color: #342D2D;
  color: white;
}
#about-username, #about-email, #about-role{
  font-size: 1.5rem;
}
#button-send{
  padding: 0.4rem;
  background-color: white;
  border-style: none;
  border-radius: 0.4rem;
  font-weight: bolder;
}
#button-send:hover{
  background-color: grey
}
</style>