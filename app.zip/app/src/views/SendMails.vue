<template>
  <div class="home">
    <div class="row">
      <div class="mt-4 col col-12 col-lg-8 p-0">
        <div class="card" id="sendMails">
          <div class="card-body pt-0">
            <h3 class="text-center">Enviar Correo</h3><hr>
            <div class="row">
              <div class="col col-8">

                <h5 class="text-center">Asunto</h5>
                <input type="text" class="form-control" v-model="subject">
              </div>
              <div class="col col 4">
                
                <h5 class="text-center">Enviar</h5>
                <select class="form-select" v-model="sendTo">
                  <option value="all">Todos</option>
                  <option value="client">Cliente</option>
                  <option value="admin">Administrador</option>
                </select>
              </div>
              
              <div class="col col-12">
                
                <h5 class="text-center mt-2">Contenido</h5>
                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" v-model="text"></textarea>
              </div>

              <div class="col col-12">
                
                <div v-if="success">

                  <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                    
                    <symbol id="check-circle-fill" fill="currentColor" viewBox="0 0 16 16">
                      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
                    </symbol>
                    
                    <symbol id="info-fill" fill="currentColor" viewBox="0 0 16 16">
                      <path d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16zm.93-9.412-1 4.705c-.07.34.029.533.304.533.194 0 .487-.07.686-.246l-.088.416c-.287.346-.92.598-1.465.598-.703 0-1.002-.422-.808-1.319l.738-3.468c.064-.293.006-.399-.287-.47l-.451-.081.082-.381 2.29-.287zM8 5.5a1 1 0 1 1 0-2 1 1 0 0 1 0 2z"/>
                    </symbol>
                    
                    <symbol id="exclamation-triangle-fill" fill="currentColor" viewBox="0 0 16 16">
                      <path d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
                    </symbol>
                  </svg>

                  <div class="alert alert-success d-flex align-items-center mt-3" role="alert">
                    
                    <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Success:"><use xlink:href="#check-circle-fill"/></svg>
                    
                    <div>
                      Todos los mensajes se han enviado satisfactoriamente
                    </div>
                  </div>
                
                </div>

                <button v-if="!success" type="button" id="button-send" class="mt-3" v-on:click="sendMails">Enviar Correos</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col col-0 col-lg-1"></div>
      <div class="card mt-4 col col-12 col-lg-3" id="aside">
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">{{configuration.name}}</h5>
                <button type="button" ref="close" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body" >
                <div class="row">
                  <div class="col col-5 text-end">
                    <strong>Usuario</strong>
                  </div>

                  <div class=" col col-7">
                    {{configuration.user}}
                  </div>
                </div>

                <div class="row">
                  <div class="col col-5 text-end">
                    <strong>Host</strong>
                  </div>

                  <div class=" col col-7">
                    {{configuration.host}}
                  </div>
                </div>

                <div class="row">
                  <div class="col col-5 text-end">
                    <strong>Puerto</strong>
                  </div>

                  <div class=" col col-7">
                    {{configuration.port}}
                  </div>
                </div>

                <div class="row">
                  <div class="col col-5 text-end">
                    <strong>Password</strong>
                  </div>

                  <div class=" col col-7">
                    {{configuration.password}}
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <div>
                  <button type="button" class="btn btn-danger" v-on:click="remove(configuration.name)" data-bs-target=".home">Eliminar</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <h3 class="text-center">Configuraciones</h3><hr>
        <div class="card-body">
          <configuration-component 
            v-for="configuration in configurations" 
            v-bind:key="configuration.id"
            v-bind:configuration="configuration"
            v-on:sendValues="click"
            v-on:returnValues="showValues">
          </configuration-component>
              
          <button type="button" id="button-send" data-bs-toggle="modal" data-bs-target="#exampleModal1">
            Agregar
          </button>

          <!-- Modal -->
          <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel1">Agregar</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <div class="modal-body" >
                    <div class="row">
                      <div class="col col-5 text-end">
                        <strong>Nombre de Configuracion</strong>
                      </div>

                      <div class=" col col-7">
                        <input class="form-control" id="name" type="text" name="name" v-model="name">
                      </div>
                    </div>

                    <div class="row">
                      <div class="col col-5 text-end">
                        <strong>Usuario</strong>
                      </div>

                      <div class=" col col-7">
                        <input class="form-control" id="user" type="text" name="user" v-model="user">
                      </div>
                    </div>

                    <div class="row">
                      <div class="col col-5 text-end">
                        <strong>Host</strong>
                      </div>

                      <div class=" col col-7">
                        <input class="form-control" id="host" type="text" name="host" v-model="host">
                      </div>
                    </div>

                    <div class="row">
                      <div class="col col-5 text-end">
                        <strong>Puerto</strong>
                      </div>

                      <div class=" col col-7">
                        <input class="form-control" id="port" type="number" name="port" v-model="port">
                      </div>
                    </div>

                    <div class="row">
                      <div class="col col-5 text-end">
                        <strong>Password</strong>
                      </div>

                      <div class=" col col-7">
                        <input class="form-control" id="password" type="text" name="password" v-model="password">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-primary" v-on:click="saveConfig">Guardar Cambios</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import axios from 'axios';
import Configuration from '@/components/Configuration.vue';

export default {
  name: 'SendMails',
  components: {
    'configuration-component': Configuration
  },
  data() {
    return {
      user: '',
      password: '',
      host: '',
      port: '',
      name: '',
      subject: '',
      text: '',
      sendTo: '',
      success: false,
      configurations: [],
      configuration: ''
    }
  },
  created(){
    axios.get('http://localhost:3000/get-configurations')
    .then(response => {
      this.configurations = response.data;
    });
  },
  methods: {
    sendMails(){
      const email = {
        sendTo: this.sendTo, 
        text: this.text, 
        subject: this.subject, 
        user: this.user,
        password: this.password, 
        host: this.host, 
        port: this.port
      };
      if(this.name == ""){
        alert("Para enviar los mails primero debe elejir una configuracion");
      }else{
        axios.post('http://localhost:3000/send-all',email)
        .then(response => {
          if(response.data.success == 'ok'){
            this.success = true;
          }
        });
      }
    },
    saveConfig(){
      const configuration = {
        name: this.name, 
        user: this.user,
        password: this.password, 
        host: this.host, 
        port: this.port
      };
      axios.post('http://localhost:3000/save-configuration',configuration)
      .then(() => {
        this.configurations.push(configuration);
      });
    },
    click(configuration){
      this.configuration = configuration;
    },
    showValues(name,user,port,host,password){
      this.name = name;
      this.user = user;
      this.port = port;
      this.host = host;
      this.password = password;
    },
    remove(name){
      axios.get(`http://localhost:3000/delete-configuration/${name}`)
      .then(() => {
        var i = 0;
        while(this.configurations[i]){
          if(this.configurations[i].name == name){
            this.configurations.splice(i,1);
          }
          i = i + 1;
        }
        this.$refs.close.click();
      });
    }
  }
}
</script>

<style scoped>
#aside{
    background-color: #342D2D;
    color: white;
}
.modal-title,.modal-body{
  color: black;
}
#sendMails{
  background-color: #342D2D;
  color: white;
}
#button-send{
  padding: 0.4rem;
  background-color: white;
  border-style: none;
  border-radius: 0.4rem;
  font-weight: bolder;
}
#button-send:hover{
  background-color: grey
}
</style>
