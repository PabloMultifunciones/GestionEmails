<template>
  <div class="about">
    <table class="table table-hover">
      <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Nombre de Usuario</th>
          <th scope="col">Rol</th>
          <th scope="col">Correo Electronico</th>
          <th scope="col">Accion</th>
        </tr>
      </thead>
      <tbody>
        <userrow-component 
          v-for="(user,index) in users" 
          v-bind:key="index"
          v-bind:user="user"
          v-on:delete="doDelete">
        </userrow-component>
      </tbody>
    </table>
  </div>
</template>

<script>
import UserRow from '@/components/UserRow.vue';
import axios from 'axios';

export default{
  components: {
    'userrow-component': UserRow
  },
  data(){
    return{
      users: []
    }
  },
  created(){
    axios.get('http://localhost:3000/all-users')
    .then(response => {
      this.users = response.data;
    })
  },
  methods: {
    doDelete(id){
      axios.get(`http://localhost:3000/delete-user/${id}`)
      .then(() => {
        for(let i = 0; i < this.users.length; i++){
          if(this.users[i].id == id){
            this.users.splice(i,1);
          }
        }
      });
    }
  }
}
</script>